<?php
  $menu = new TMenuDhtmlx();
  $menu->add(1,0,'mplo','tela_exemplo.php');
  $menu->getXml();
?>
